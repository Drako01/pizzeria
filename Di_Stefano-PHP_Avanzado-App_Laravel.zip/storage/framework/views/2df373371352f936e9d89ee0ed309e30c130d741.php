<?php $__env->startSection('contenido'); ?>
<section class="acerca" id="acerca">
    <div class="acerca_de">

        <p>
            Desde el corazón de Nuñez los llevamos por un viaje gastronómico a la ciudad de Nápoles degustando de nuestras pizzas
            estilo napoletano siguiendo las recetas tradicionales con la más alta calidad de productos importados e ingredientes italianos.

            La comida, los tragos y los vinos que ofrecemos se disfrutan entre amigos, familia o una cita íntima con tu pareja en nuestro
            ambiente cálido del salón o en nuestro hermoso patio al aire libre.
        </p>

    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Git\PHP Avanzado\entrega-final\pizzeria\resources\views/pages/acerca_de.blade.php ENDPATH**/ ?>