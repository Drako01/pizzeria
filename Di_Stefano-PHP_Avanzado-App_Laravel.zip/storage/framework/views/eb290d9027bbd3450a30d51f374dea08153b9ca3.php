<?php $__env->startSection('contenido'); ?>
<section class="fotos_pizzas">
<div class="titulo">Nuestras Especialidades</div>
<div class="line"></div>
<section class="productos">
    <section class="producto_item">
        <div class="item-titulo item_01">
            <h2><u></u></h2>
            <h3></h3>
        </div>
        <div class="item item_01">
            <img src="img/001.jpeg">
            <img src="img/002.jpg">
            <img src="img/003.jpg">
            <img src="img/004.jpg">
            <img src="img/005.jpg">
            <img src="img/006.jpg">

        </div>
    </section>
    <section class="producto_item">
        <div class="item-titulo item_02">
            <h2><u></u></h2>
            <h3></h3>
        </div>
        <div class="item item_02">
            <img src="img/007.jpg">
            <img src="img/008.jpg">
            <img src="img/009.jpg">
            <img src="img/010.jpg">
            <img src="img/011.webp">
            <img src="img/012.jpg">
        </div>
    </section>
</section>
<div class="line"></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Git\PHP Avanzado\entrega-final\pizzeria\resources\views/pages/fotos.blade.php ENDPATH**/ ?>