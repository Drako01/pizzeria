<?php $__env->startSection('contenido'); ?>
<section id="contenido">

    <div class="body_bg01"></div>

    <div class="logo">
        <img src="img/logo.png">
    </div>

    <div class="body_bg02"></div>
</section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Git\PHP Avanzado\entrega-final\pizzeria\resources\views/index.blade.php ENDPATH**/ ?>